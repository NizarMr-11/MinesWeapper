public class SquareStatus {
    // Note that a square status is a (part-of ) the square which means a
    // square status can not be existed without the square

    private String status;
    private int numSquare;//the number will be in the square if the square was surrounded by one or more mines
}
