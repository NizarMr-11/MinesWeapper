public class Square {
    //Note that this class will have 1 or more instances from the SquareStatus class which means a
    //square status is a (part of) the square

    // Note that a square is a (part-of ) the grid which means a
    // square can not be existed without the grid

    private int x;
    private int y;
    private SquareStatus status;

    public boolean isMine(){};
}
