public abstract class Game {
    //the main game class
    //Note that this class will have 1 or more instances from the player class which means a
    //  player is a (part-of) the game

    protected Player [] players;
    protected Player currentPlayer;
    protected GameRules gameRules;
    protected Grid grid;

    public void initGame(){};//the return type can be smth else
    public void applyPlayerMove(){};//the return type can be smth else

    public abstract class GameRules{

        public abstract double getScoreChange(){};//the return type can be smth else and IT NEEDS TO BE IMPLEMENTED IN THE SUB-CLASSES

        public abstract Player decideNextPlayer(){}; //IT NEEDS TO BE IMPLEMENTED IN THE SUB-CLASSES
    }
}
