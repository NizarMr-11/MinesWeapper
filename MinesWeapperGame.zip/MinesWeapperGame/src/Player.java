public abstract class Player {
    // Note that a player is a (part-of ) the game which means a
    // player can not be existed without the game

    protected String name;
    protected String score;
    protected String color;

    public abstract void playerMove(){};//the return type can be smth else
}
