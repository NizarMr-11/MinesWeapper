public class Grid {
    //Note that this class will have 1 or more instances from the Square class which means a
    //square is a (part-of) the grid

    private int width;
    private int height;
    private int numOfMines;
    private Square[][] squares;

    public void distrbuteMines(){};//the return type can be smth else
    public void showGrid(){};//the return type can be smth else
}
