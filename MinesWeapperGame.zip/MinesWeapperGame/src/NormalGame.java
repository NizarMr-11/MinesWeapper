public abstract class NormalGame extends Game{
    // Note that A Normal game (has-a)default game rules which means a

    public DefaultGameRules rules;

    @Override
    public void initGame(){};//the return type can be smth else
    public void singlePlayer(){};//the return type can be smth else
    public abstract class DefaultGameRules extends GameRules{

    }
}
