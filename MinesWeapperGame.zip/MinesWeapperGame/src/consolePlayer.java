public abstract class consolePlayer extends Player {
    @Override
    public abstract void playerMove(){};// the return type can be smth else and IT NEEDS TO BE IMPLEMENTED IN THE SUB-CLASSES
}
