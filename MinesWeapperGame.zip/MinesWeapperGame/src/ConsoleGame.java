public abstract class ConsoleGame extends NormalGame  {
    //Note that this class will have 0 or more instances from the ConsolePlayer class which means a
    //console player is a (part of) the console game

    @Override
    public void initGame(){};//the return type can be smth else

    public void singlePlayer(){};//the return type can be smth else
}
